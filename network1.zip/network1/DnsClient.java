/**
* Java 1.8
*
* Compile:
*   javac DnsClient.java
* Run:
* java DnsClient [-t timeout] [-r max-retries] [-p port] [-mx|-ns] @server name
* where the arguments are defined as follows.
*       - timeout (optional) gives how long to wait, in seconds, 
*         before retransmitting an unanswered query. Default value: 5.
*       - max-retries (optional) is the maximum number of times to retransmit 
*         an unanswered query before giving up. Default value: 3.
*       - port (optional) is the UDP port number of the DNS server. 
*         Default value: 53.
*       - -mx or -ns flags (optional) indicate whether to send 
*         a MX (mail server) or NS (name server) query. 
*         At most one of these can be given, and if neither is given then 
*         the client should send a type A (IP address) query.
*       - server (required) is the IPv4 address of the DNS server, 
*         in a.b.c.d. format
*       - name (required) is the domain name to query for.
*
*/
/**
* Tested:
* OpenDNS 208.67.222.222
* Cloudflare 1.1.1.1
* Google Public DNS 8.8.8.8
* Comodo Secure DNS 8.26.56.26
* Verisign Public DNS 64.6.65.6
* Quad9. 9.9.9.9
* UncensoredDNS 91.239.100.100
* CleanBrowsing 185.228.168.168
* Yandex DNS 77.88.8.7
* Alternate DNS 198.101.242.72
* AdGuard DNS 176.103.130.130
*/

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;// random numbers

/**
 * The class of the DNS client.
 */

public class DnsClient {

    private static final int AA = 5;
    private static final int TC = 6;
    private static final int RD = 7;
    private static final int RA = 8;
    
    private static final int PORT = 53;
    private static final int TIMEOUT = 5;
    private static final int MAX_RETRIES = 3;
    private static final short A = 1; // host request
    private static final short NS = 2; // name server
    private static final short CNAME = 5;
    private static final short SOA = 6;
    private static final short MB = 7;
    private static final short WKS = 11;
    private static final short PTR = 12;
    private static final short HINFO = 13;
    private static final short MINFO = 14;
    private static final short MX = 15;
    private static final short TXT = 16;
    private static final short AXFR = 252;    

    public static void main(String[] args) throws IOException {
    
        int timeout = TIMEOUT*1000;
        int port = PORT;
        int maxRetries = MAX_RETRIES;
        short type = A;
        String server = null;
        String name = null;
        short id = 0;
        
        if(args.length < 2) {
            printHelp();
            return;
        }
        
        // Parsing command line arguments.
        for(int i = 0; i < args.length; i ++) {
            if(args[i].equals("-p")) {
                if(i < args.length - 1) {
                    port = Integer.parseInt(args[i+1]);
                }
            } else if(args[i].equals("-t")) {
                if(i < args.length - 1) {
                    timeout = Integer.parseInt(args[i+1]);
                    timeout *= 1000;
                }
            } else if(args[i].equals("-r")) {
                if(i < args.length - 1) {
                    maxRetries = Integer.parseInt(args[i+1]);
                }
            } else if(args[i].equals("-mx")) {
                type = MX;
            } else if(args[i].equals("-ns")) {
                type = NS;
            } else if (args[i].contains("@")) {
                String ip = args[i].substring(1);
                String[] octets = ip.split("\\.");
                for (int j = 0; j < octets.length; j++) {
                    int val = Integer.parseInt(octets[j]);
                    if (val < 0 || val > 255) {
                        System.out.println("ERROR: invalid " + 
                                    "octet of IP address (" + val +  "), " + 
                                    "must be between 0 and 255 inclusive.");
                        return;
                    }
                }
                server = ip;
            } else {
                name = args[i];
            }
        }
        
        if(server == null || name == null) {
            printHelp();
            return;
        }
        
        InetAddress ipAddress = InetAddress.getByName(server);

        // Build a DNS request

        // We recommend that your application use a new 
        // random 16-bit number for each request.
        id = (short)ThreadLocalRandom.current().nextInt(Short.MIN_VALUE, 
                                                        Short.MAX_VALUE);
        byte[] dnsFrame = null;
        try {
            dnsFrame = encodeRequest(name, id, type);
        } catch(IOException ex) {
            ex.printStackTrace();
            dnsFrame = null;
        }
        if(dnsFrame == null) {
            return;
        }
        
        // Request start time.
        long start = System.currentTimeMillis();
        
        byte[] buf = null;
        for(int i = 0; i < maxRetries; i ++) {
            try {
                buf = dnsRequest(ipAddress, port, timeout,dnsFrame);
            } catch (IOException ex) {
                buf = null;
                ex.printStackTrace();
            }
            if(buf != null) {
                maxRetries = i;
                break;
            }
        }
        
        if(buf == null) {
            return;
        }
        
        // Request end time.
        long end = System.currentTimeMillis();
        // Request execution time in seconds.
        float sec = (end - start) / 1000F;
        // Analysis of the answer and printing.
        decodeResponse(name, server, type, maxRetries, sec, buf);
    }
    
    private static void printHelp() {
        System.out.println("java DnsClient [-t timeout] [-r max-retries] " + 
                                    "[-p port] [-mx|-ns] @server name");
    }
    
    // Collection of data for the request.
    private static byte[] encodeRequest(String name, short id, short type)
                                                        throws IOException {
    
        short flags = 0;
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        
        dos.writeShort(id);
  
        // The program should set this bit RD to 1 
        // to indicate that recursion is desired.
        flags = setBit(flags, RD);
        // write flags
        dos.writeShort(flags);

        // question count
        dos.writeShort(0x0001);

        // answer record count
        dos.writeShort(0x0000);

        // authority record count
        dos.writeShort(0x0000);

        // additional record count.
        dos.writeShort(0x0000);

        String[] domainParts = name.split("\\.");

        for (int i = 0; i < domainParts.length; i++) {
            byte[] domainBytes = domainParts[i].getBytes("UTF-8");
            dos.writeByte(domainBytes.length);
            dos.write(domainBytes);
        }

        // no more parts
        dos.writeByte(0x00);

        // request type. 
        dos.writeShort(type);

        // class 0x01 = IN
        dos.writeShort(0x0001);

        byte[] dnsFrame = baos.toByteArray();
        
        return dnsFrame;
    }
    
    // Submit a request.
    private static byte[] dnsRequest(InetAddress ip, int port, 
                                        int timeout, byte[] frame) 
                                        throws IOException {
        DatagramSocket socket = new DatagramSocket();
        DatagramPacket dnsReqPacket = new DatagramPacket(frame, 
                                                        frame.length, 
                                                        ip, port);
        socket.send(dnsReqPacket);

        // Await response from DNS server
        byte[] buf = new byte[1024];
        
        socket.setSoTimeout(timeout);
        
        try {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);
        } catch(SocketTimeoutException ex) {
            System.out.println("Timeout reached.");
            buf = null;
        } finally {
            socket.close();
        }
        
        return buf;
    }

    private static String getErrorMessage(int rcode) {
        String msg = "";
	    switch( rcode) {
            case 0:
                break;
            case 1:
                msg = "The name server was unable to interpret the query.";
            case 2:
                msg = "The name server was unable to process this query " + 
                        "due to a problem with the name server";
            case 3:
                msg = "NOTFOUND";
            case 4:
                msg = "The name server does not support the requested " + 
                                                            "kind of query";
            case 5:
                msg = "The name server refuses to perform " + 
                                "the requested operation for policy reasons";
        }
        return msg;
    }
    
    // Parsing one line in one of the response sections.
    private static int parseLine(byte[] resp, int n, String host, 
                                                        RecordData rd) {
        int pos = n;
        ByteBuffer buffer = ByteBuffer.wrap(resp);
        buffer.position(pos);
        byte point = buffer.get();
        if((point & 0xc0) == 0xc0 ) {
            pos += 2;
        } else {
            pos += 1 + host.length() + 1;
        }
        
        buffer.position(pos);
        rd.queryType =  buffer.getShort();
        pos += 2;
        
        buffer.position(pos);
        rd.queryClass =  buffer.getShort();
        pos += 2;
        rd.ttl =  buffer.getInt();
        pos += 4;
        
        buffer.position(pos);
		rd.dataLen = buffer.getShort();
		pos +=2;
		
		return pos;
    }
    
    private static void parseHeader(byte[] resp, HeaderData hd) {
    
        ByteBuffer buffer = ByteBuffer.wrap(resp);
		int pos = 2;
		buffer.position(pos);
		short flags = buffer.getShort();
		hd.ra = getBit(flags, RA);
		boolean auth = getBit(flags, AA);
		
		byte b = resp[2];
        //boolean auth = getBit(b, 2);
		
		if(auth) {
            hd.auth = "auth";
		} else {
            hd.auth = "noauth";
		}
        // QDCOUNT
		// Is an unsigned 16-bit integer specifying the number of 
		// entries in the question section. 
		// This will always be 1 for this program.
        byte[] buf = new byte[2];
        buf[0] = resp[4];
        buf[1] = resp[5];
        ByteBuffer bb = ByteBuffer.wrap(buf);
        hd.qdcount = bb.getShort();
        
        // ANCOUNT
        // Is an unsigned 16-bit integer specifying the number of 
        // resource records in the answer section.
        buf = new byte[2];
        buf[0] = resp[6];
        buf[1] = resp[7];
        bb = ByteBuffer.wrap(buf);
        hd.ancount = bb.getShort();

        // NSCOUNT
        // Is an unsigned 16-bit integer specifying the number of 
        // name server resource records in the Authority section.
        // The program ignore any response entries in this section.
        buf = new byte[2];
        buf[0] = resp[8];
        buf[1] = resp[9];
        bb = ByteBuffer.wrap(buf);
        hd.nscount = bb.getShort();

        // ARCOUNT
        // Is an unsigned 16-bit integer specifying the number of 
        // resource records in the Additional records section.
        buf = new byte[2];
        buf[0] = resp[10];
        buf[1] = resp[11];
        bb = ByteBuffer.wrap(buf);
        hd.arcount = bb.getShort();
    
        hd.rcode = resp[3] & 0x0F;
    }
    
    private static void decodeResponse(String host, String server, 
                                                short type, int maxRetries, 
                                                float sec, byte[] resp) {
		
		HeaderData hd = new HeaderData();
		parseHeader(resp, hd);    
        
		ByteBuffer buffer = ByteBuffer.wrap(resp);
		int pos = 6;
		
		buffer.position(pos);
		pos = 12 + 1 + host.length() + 1 + 4;
		buffer.position(pos);
		
		// Print general information.
		System.out.println("DnsClient sending request for " + host );
        System.out.println("Server: " + server );
        String s = getRecordType(type);
        System.out.println("Request type: " + s);
        
        System.out.println("Response received after " + sec + " seconds" + 
                                            "(" + maxRetries + " retries)");
        if(! hd.ra) {
            System.out.println("The server does not support recursive queries");
        }
        
        System.out.println();
        
        if(hd.rcode != 0) {
            String msg = getErrorMessage(hd.rcode);
            System.out.println(msg);
            return;
        }
        
        if(hd.ancount <= 0) {
            System.out.println("NOTFOUND");
            return;
        }
        
        // Print an answer section.
        System.out.println("***Answer Section (" + hd.ancount + 
                                                            " records)***");
		for(int i= 0 ; i < hd.ancount; i++ ) {
		
            RecordData rd = new RecordData();
            pos = parseLine(resp, pos, host, rd);
            
			if(rd.queryType == A) {
				String ip = getIpAddress(buffer, pos, rd.dataLen);				
				System.out.println("IP\t" + ip + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
			} else if(rd.queryType == CNAME) {
				String alias = getName(resp, pos);
				System.out.println("CNAME\t" + alias + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
			} else if(rd.queryType == NS) {
				String alias = getName(resp, pos);
				System.out.println("NS\t" + alias + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
			}else if(rd.queryType == MX) {
				String alias = getName(resp, pos+2);
				System.out.println("MX\t" + alias + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
			} 
			pos += rd.dataLen;
		}
		
		System.out.println();
		
		// The program ignore any response entries in this section.
		for(int i= 0 ; i < hd.nscount; i++ ) {
		
            RecordData rd = new RecordData();
            pos = parseLine(resp, pos, host, rd);
			pos += rd.dataLen;
		}
		
		// Print an additional section.
		if(hd.arcount > 0) {
            System.out.println("***Additional Section (" + hd.arcount + 
                                                            " records)***");
            for(int i= 0 ; i < hd.arcount; i++ ) {
            
                RecordData rd = new RecordData();
                pos = parseLine(resp, pos, host, rd);
                
                if(rd.queryType == A) {
                    String ip = getIpAddress(buffer, pos, rd.dataLen);				
                    System.out.println("IP\t" + ip + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
                } else if(rd.queryType == CNAME) {
                    String alias = getName(resp, pos);
                    System.out.println("CNAME\t" + alias + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
                } else if(rd.queryType == NS) {
                    String alias = getName(resp, pos);
                    System.out.println("NS\t" + alias + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
                }else if(rd.queryType == MX) {
                    String alias = getName(resp, pos+2);
                    System.out.println("MX\t" + alias + "\t" + rd.ttl + 
                                                            "\t" + hd.auth);
                } 
                pos += rd.dataLen;
            }
            
            System.out.println();
		}
    }
    
    // Gets the ip address from the response string.
    private static String getIpAddress(ByteBuffer buffer, int pos, 
                                                            short dataLen) {
        String ip = "";
        for(short j = 0; j < dataLen ; j ++) {
            buffer.position(pos);
            int v  = buffer.get();
            v = v > 0 ? v : 0x0ff & v;
            ip += v + (j == dataLen - 1 ? "" : ".");
            pos+=1;
        }
        return ip;
    }
    
    // Gets the host name from the response string.
    private static String getName(byte[] buf, int index){
        int pos = index;
    	int size = buf[pos];
    	int count = 0;    	
    	boolean start = true;
    	String name = "";
    	while( size != 0 ){
			if (! start){
				name += ".";
			}
	    	if ((size & 0xC0) == (int) 0xC0) {
	    		byte[] offset = { (byte) (buf[pos] & 0x3F), buf[pos + 1] };
	            ByteBuffer bb = ByteBuffer.wrap(offset);
	            int idx = bb.getShort();
	            name += getName(buf, idx);
	            pos += 2;
	            count += 2;
	            size = 0;
	    	} else {
	    		name += getWord(buf, pos);
	    		pos += size + 1;
	    		count += size + 1;
	    		size = buf[pos];
	    	}
            start = false;
    	}
    	return name;
    }
    
    // Gets a single word from the response string.
    private static String getWord(byte[] buf, int pos){
    	String word = "";
    	int size = buf[pos];
    	for(int i = 0; i < size; i++){
    		word += (char) buf[pos + i + 1];
		}
    	return word;
    }
    
    private static short setBit(short s, int n) {
        return (short)( s | (short)(1 << n));
    }
    
    private static boolean getBit(short s, int n) {
        return (((s >>> n) & 1) != 0);
    }
    
    // The data type in the response.
    // Almost all types that may occur are represented.
    private static String getRecordType(short type) {
        String s = "A";
        switch(type) {
            case NS:
                s = "NS";
            break;
            case CNAME:
                s = "CNAME";
            break;
            case SOA:
                s = "SOA";
            break;
            case MB:
                s = "MB";
            break;
            case WKS:
                s = "WKS";
            break;
            case PTR:
                s = "PTR";
            break;
            case HINFO:
                s = "HINFO";
            break;
            case MINFO:
                s = "MINFO";
            break;
            case MX:
                s = "MX";
            break;
            case TXT:
                s = "TXT";
            break;
            case AXFR:
                s = "AXFR";
            break;
            default:
            break;
        }
        return s;
    }
    
    private static void printByteArray(byte[] data) {
        for(int i = 0; i < data.length; i ++) {
            System.out.print(String.format("%x ", data[i]));
        }
        
        System.out.println();
    }
}

// The data in the response header.
class HeaderData {
    short qdcount;
    short ancount;
    short nscount;
    short arcount;
    int rcode;
    String auth;
    boolean ra;
}

// Data in one line of response.
class RecordData {
    short queryType;
    short queryClass;
    int ttl;
    short dataLen;
}

